﻿#!/bin/bash
clear
echo "";
echo "#######################################################○○○○○#○○○○○#○○○####○###○###○#########################○#####○##○##○##○#○###○#○#########################○#####○###○○○##○○○○○###○#####OSIF###############○○○○○#○○○○○#○####○###○###○####TOOLS############################################################";
sleep 5
echo "**********WELLCOME TO OSIF TOOLS @ZzpaY***********";
echo "##################################################";
echo "BACA DULU BOS!!!!!!!";
sleep 3
echo "";
echo "1. login dulu akun FB anda menggunakan FB Lite atau Browser bawaan hp anda untuk menghindari akun kena CHECK POIN";
sleep 2
echo "2. Gunakan dengan BIJAK!!!!";
read -p "TEKAN Enter Jika SETUJU!!!!!" a;
echo "》》》》》LOADING OSIF TOOLS《《《《《";
sleep 3
echo "0% load python2";
sleep 3
echo "10% load config*********";
sleep 5
echo "25% load sql.dll*******************";
sleep 7
echo "75% load osif.inf***************************";
sleep 5
echo "100% load complited*******************************";
sleep 5
echo  "ALL OK!";
sleep 5
python2 osif.py
